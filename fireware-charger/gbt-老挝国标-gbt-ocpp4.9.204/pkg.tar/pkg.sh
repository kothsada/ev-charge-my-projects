tar -pcvf pkg.tar ./*

